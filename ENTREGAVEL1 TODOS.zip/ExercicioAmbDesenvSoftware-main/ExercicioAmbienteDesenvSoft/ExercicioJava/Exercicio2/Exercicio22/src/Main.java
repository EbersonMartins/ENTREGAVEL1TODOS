public class Main {
    EhPrimo ehPrimo = new EhPrimo();
    public static void main(String[] args) {
        int n = 5;
        boolean Primo = EhPrimo.ehPrimo(n);
        System.out.println(Primo);
    }
}